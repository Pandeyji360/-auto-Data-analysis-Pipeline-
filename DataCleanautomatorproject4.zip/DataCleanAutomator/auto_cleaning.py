#!/usr/bin/env python3
"""
Auto Cleaning Module
------------------
This module provides automatic data cleaning capabilities
with different levels of aggressiveness and intelligent detection
of cleaning strategies.

Author: Senior Data Engineer
Date: May 5, 2025
Version: 1.0
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Union, Any, Optional
import time
from functools import wraps

# Define a simple log_action function if logger module is not available
def log_action(message, level="INFO"):
    """
    Log an action with the specified level.
    
    Args:
        message (str): Message to log
        level (str): Logging level (INFO, WARNING, ERROR, DEBUG)
    """
    print(f"[{level}] {message}")

from data_cleaning import (
    identify_data_issues,
    get_data_quality_report,
    suggest_cleaning_strategy,
    clean_data,
    auto_clean_data
)

# For large dataset handling
try:
    import dask.dataframe as dd
    DASK_AVAILABLE = True
except ImportError:
    DASK_AVAILABLE = False


def timing_decorator(func):
    """Decorator to measure execution time of functions"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        log_action(f"Function {func.__name__} executed in {execution_time:.2f} seconds")
        return result, execution_time
    return wrapper


@timing_decorator
def analyze_and_suggest(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Analyze data and suggest cleaning operations without modifying the data.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        
    Returns:
        Dict[str, Any]: Analysis results including issues and suggested strategies
    """
    log_action("Starting data analysis for auto-cleaning suggestions")
    
    # Initialize results dictionary
    results = {
        'data_summary': {
            'rows': len(df),
            'columns': len(df.columns),
            'memory_usage_mb': df.memory_usage(deep=True).sum() / (1024 * 1024)
        },
        'issues_detected': {},
        'cleaning_suggestions': {},
        'estimated_impact': {}
    }
    
    # Get data issues
    results['issues_detected'] = identify_data_issues(df)
    
    # Get cleaning suggestions
    results['cleaning_suggestions'] = suggest_cleaning_strategy(df)
    
    # Estimate impact of cleaning
    total_cells = df.size
    impacted_cells = 0
    
    for column, issues in results['issues_detected'].items():
        column_impact = 0
        
        # Count missing values
        if 'missing_values' in issues:
            column_impact += issues['missing_values']['count']
        
        # Count outliers
        if 'outliers' in issues:
            column_impact += issues['outliers']['count']
        
        # Count other issues
        if 'empty_strings' in issues:
            column_impact += issues['empty_strings']['count']
        
        if 'whitespace_strings' in issues:
            column_impact += issues['whitespace_strings']['count']
        
        # Add to total impacted cells
        impacted_cells += column_impact
        
        # Store column impact
        if column_impact > 0:
            results['estimated_impact'][column] = {
                'impacted_cells': column_impact,
                'impact_percent': (column_impact / len(df)) * 100
            }
    
    # Calculate overall impact percentage
    results['overall_impact'] = {
        'total_cells': total_cells,
        'impacted_cells': impacted_cells,
        'impact_percent': (impacted_cells / total_cells) * 100 if total_cells > 0 else 0
    }
    
    # Generate a human-readable summary of issues for quick understanding
    issue_summary = {}
    for column, issues in results['issues_detected'].items():
        issue_list = []
        
        # Process each issue type for this column
        if 'missing_values' in issues:
            missing_count = issues['missing_values']['count']
            missing_percent = issues['missing_values']['percent']
            issue_list.append(f"Missing Values: {missing_count:,} ({missing_percent:.1f}%)")
        
        if 'outliers' in issues:
            outlier_count = issues['outliers']['count']
            outlier_percent = issues['outliers']['percent']
            issue_list.append(f"Outliers: {outlier_count:,} ({outlier_percent:.1f}%)")
            
        if 'inconsistent_formats' in issues:
            issue_list.append("Inconsistent formats detected")
            
        if 'duplicates' in issues:
            issue_list.append(f"Duplicate values: {issues['duplicates']['count']} rows")
            
        if 'empty_strings' in issues:
            issue_list.append(f"Empty strings: {issues['empty_strings']['count']}")
            
        if 'whitespace_strings' in issues:
            issue_list.append(f"Whitespace-only strings: {issues['whitespace_strings']['count']}")
        
        # Add to summary if there are issues
        if issue_list:
            issue_summary[column] = issue_list
    
    # Add the issue summary to results
    results['issue_summary'] = issue_summary
    
    # Add recommended aggressiveness level based on impact
    impact_percent = results['overall_impact']['impact_percent']
    if impact_percent < 5:
        recommended_level = 'minimal'
    elif impact_percent < 15:
        recommended_level = 'moderate'
    else:
        recommended_level = 'aggressive'
    
    results['recommended_aggressiveness'] = recommended_level
    
    return results


@timing_decorator
def perform_auto_cleaning(df: pd.DataFrame, aggressiveness: str = 'moderate') -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Perform automatic data cleaning with specified aggressiveness level.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        aggressiveness (str): Level of cleaning aggressiveness: 'minimal', 'moderate', or 'aggressive'
        
    Returns:
        Tuple[pd.DataFrame, Dict[str, Any]]: Cleaned DataFrame and cleaning results
    """
    log_action(f"Starting auto-cleaning with {aggressiveness} aggressiveness level")
    
    # Perform auto-cleaning
    cleaned_df, cleaning_log = auto_clean_data(df, aggressiveness=aggressiveness)
    
    # Compile detailed cleaning results
    results = {
        'cleaning_log': cleaning_log,
        'stats': {
            'rows_before': cleaning_log['rows_before'],
            'rows_after': cleaning_log['rows_after'],
            'columns_before': cleaning_log['columns_before'],
            'columns_after': cleaning_log['columns_after'],
            'rows_removed': cleaning_log['rows_removed'],
            'columns_removed': cleaning_log['columns_removed'],
            'columns_modified': len(cleaning_log['operations_by_column'])
        },
        'aggressiveness': aggressiveness
    }
    
    # Calculate data quality improvement
    original_quality = get_data_quality_report(df)
    cleaned_quality = get_data_quality_report(cleaned_df)
    
    # Calculate missing data reduction
    original_missing = original_quality['missing_data']['total_missing_cells']
    cleaned_missing = cleaned_quality['missing_data']['total_missing_cells']
    
    results['quality_improvement'] = {
        'missing_values_before': int(original_missing),
        'missing_values_after': int(cleaned_missing),
        'missing_values_reduction': int(original_missing - cleaned_missing),
        'missing_values_reduction_percent': 
            ((original_missing - cleaned_missing) / original_missing * 100) if original_missing > 0 else 0,
        'duplicate_rows_removed': int(original_quality['duplicate_rows']['count'] - cleaned_quality['duplicate_rows']['count'])
    }
    
    return cleaned_df, results


def compare_cleaning_options(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Compare different cleaning aggressiveness levels and their impacts.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        
    Returns:
        Dict[str, Any]: Comparison results
    """
    log_action("Comparing different auto-cleaning options")
    
    comparison = {
        'original_shape': df.shape,
        'options': {}
    }
    
    # Get analysis and suggestions
    analysis_results, _ = analyze_and_suggest(df)
    comparison['analysis'] = analysis_results
    
    # Define aggressiveness levels to compare
    levels = ['minimal', 'moderate', 'aggressive']
    
    # Process each level
    for level in levels:
        log_action(f"Testing {level} cleaning level")
        
        # Apply cleaning
        cleaned_df, results = perform_auto_cleaning(df, level)
        results_without_time = results[0] if isinstance(results, tuple) else results
        execution_time = results[1] if isinstance(results, tuple) else 0
        
        # Store results
        comparison['options'][level] = {
            'resulting_shape': cleaned_df.shape,
            'execution_time': execution_time,
            'rows_removed': results_without_time['stats']['rows_removed'],
            'columns_removed': results_without_time['stats']['columns_removed'],
            'columns_modified': results_without_time['stats']['columns_modified'],
            'missing_values_reduction_percent': results_without_time['quality_improvement']['missing_values_reduction_percent'],
            'summary': f"{level.capitalize()} cleaning: {results_without_time['stats']['columns_modified']} columns modified, "
                     f"{results_without_time['quality_improvement']['missing_values_reduction_percent']:.1f}% missing values reduction"
        }
    
    # Determine recommended option
    impact_percent = analysis_results['overall_impact']['impact_percent']
    if impact_percent < 5:
        recommended = 'minimal'
    elif impact_percent < 15:
        recommended = 'moderate'
    else:
        recommended = 'aggressive'
    
    comparison['recommended_option'] = recommended
    comparison['recommendation_reason'] = (
        f"Based on {impact_percent:.1f}% of data requiring cleaning, "
        f"'{recommended}' aggressiveness is recommended to balance thoroughness and data preservation."
    )
    
    return comparison


def generate_cleaning_preview(df: pd.DataFrame, aggressiveness: str = 'moderate', sample_rows: int = 5) -> Dict[str, Any]:
    """
    Generate a preview of cleaning operations without modifying the full dataset.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        aggressiveness (str): Level of cleaning aggressiveness
        sample_rows (int): Number of rows to include in before/after samples
        
    Returns:
        Dict[str, Any]: Preview results including sample rows before/after
    """
    log_action(f"Generating cleaning preview with {aggressiveness} aggressiveness")
    
    # Get sample rows that have issues for better demonstration
    issues = identify_data_issues(df)
    
    # Create masks for each issue type
    issue_masks = {}
    for column, column_issues in issues.items():
        if 'missing_values' in column_issues:
            issue_masks[f"{column}_missing"] = df[column].isna()
        
        if 'outliers' in column_issues:
            q1 = df[column].quantile(0.25)
            q3 = df[column].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - (1.5 * iqr)
            upper_bound = q3 + (1.5 * iqr)
            issue_masks[f"{column}_outlier"] = (df[column] < lower_bound) | (df[column] > upper_bound)
    
    # Combine masks to find rows with issues
    if issue_masks:
        combined_mask = pd.Series(False, index=df.index)
        for mask in issue_masks.values():
            combined_mask = combined_mask | mask
        
        # Get sample rows with issues
        sample_indices = df[combined_mask].index[:sample_rows].tolist()
        
        # If not enough rows with issues, add random rows
        if len(sample_indices) < sample_rows:
            additional_indices = df[~combined_mask].sample(min(sample_rows - len(sample_indices), len(df[~combined_mask]))).index.tolist()
            sample_indices.extend(additional_indices)
    else:
        # No issues found, use random sample
        sample_indices = df.sample(min(sample_rows, len(df))).index.tolist()
    
    # Extract sample dataframe
    sample_df = df.loc[sample_indices].copy()
    
    # Apply cleaning to the sample
    cleaned_sample, cleaning_log = auto_clean_data(sample_df, aggressiveness=aggressiveness)
    
    # Prepare preview result
    preview = {
        'sample_before': sample_df.to_dict('records'),
        'sample_after': cleaned_sample.to_dict('records'),
        'cleaning_operations': cleaning_log['operations_by_column'],
        'aggressiveness': aggressiveness,
        'sample_size': len(sample_df)
    }
    
    return preview


# Main execution (for testing purposes)
if __name__ == "__main__":
    # Create sample DataFrame
    data = {
        'age': [25, 30, np.nan, 40, 35, 999, 28, np.nan],
        'income': [50000, 60000, 75000, np.nan, 65000, 55000, np.nan, 80000],
        'email': ['user@example.com', 'invalid', np.nan, 'test@test.com', 'another@example.com', '', 'USER@EXAMPLE.COM', np.nan],
        'date_joined': ['2020-01-15', '01/20/2020', np.nan, '2020/03/01', '2020-04-15', '01-05-2020', np.nan, '2050-01-01']
    }
    df = pd.DataFrame(data)
    
    # Compare cleaning options
    comparison = compare_cleaning_options(df)
    
    # Print comparison results
    print("Cleaning Options Comparison:")
    for level, results in comparison['options'].items():
        print(f"\n{level.capitalize()}:")
        print(f"  Execution time: {results['execution_time']:.2f} seconds")
        print(f"  Columns modified: {results['columns_modified']}")
        print(f"  Missing values reduction: {results['missing_values_reduction_percent']:.1f}%")
    
    print(f"\nRecommended option: {comparison['recommended_option']}")
    print(f"Reason: {comparison['recommendation_reason']}")
