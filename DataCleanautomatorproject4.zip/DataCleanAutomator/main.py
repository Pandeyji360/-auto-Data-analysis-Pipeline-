#!/usr/bin/env python3
"""
Data Analysis Pipeline Application - Main Entry Point
----------------------------------------------------
This script serves as the main entry point for the Automated Data Analysis Pipeline application.
It launches the Streamlit web application with proper configuration.

Author: Senior Data Engineer
Date: May 6, 2025
Version: 1.0
"""

import os
import sys
import streamlit.web.cli as stcli
from pathlib import Path

def main():
    """Main function to run the Streamlit application."""
    # Set up environmental variables
    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    os.environ["STREAMLIT_SERVER_ADDRESS"] = "0.0.0.0"
    os.environ["STREAMLIT_SERVER_PORT"] = "5000"
    
    # Create .streamlit directory and config if it doesn't exist
    setup_streamlit_config()
    
    # Get the directory of this script
    current_dir = Path(__file__).parent.absolute()
    
    # Path to the app.py file
    app_path = current_dir / "app.py"
    
    # Run the streamlit app
    sys.argv = [
        "streamlit", "run", 
        str(app_path),
        "--server.port=5000",
        "--server.address=0.0.0.0"
    ]
    
    # Initialize any needed resources
    print("Starting Automated Data Analysis Pipeline...")
    print(f"Access the application at http://localhost:5000")
    
    # Launch the application
    stcli.main()

def setup_streamlit_config():
    """Create streamlit config directory and configuration file."""
    # Ensure .streamlit directory exists
    config_dir = Path.home() / ".streamlit"
    config_dir.mkdir(exist_ok=True)
    
    # Create config.toml if it doesn't exist
    config_file = config_dir / "config.toml"
    
    if not config_file.exists():
        config_content = """
[server]
headless = true
enableCORS = false
enableXsrfProtection = false
address = "0.0.0.0"
port = 5000

[theme]
primaryColor = "#4CAF50"
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F0F2F6"
textColor = "#262730"
font = "sans serif"
        """
        
        with open(config_file, "w") as f:
            f.write(config_content)
            
        print(f"Created Streamlit configuration at {config_file}")

if __name__ == "__main__":
    main()