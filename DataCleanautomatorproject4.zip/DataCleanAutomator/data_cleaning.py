#!/usr/bin/env python3
"""
Data Cleaning Module
-------------------
This module provides functions for data cleaning, including:
- Identifying data quality issues
- Getting data quality reports
- Suggesting cleaning strategies
- Cleaning data using different methods

Author: Senior Data Engineer
Date: May 5, 2025
Version: 1.1
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Union, Any, Optional
import re
from datetime import datetime
import logging

# Define a simple log_action function if logger module is not available
def log_action(message, level="INFO"):
    """
    Log an action with the specified level.
    
    Args:
        message (str): Message to log
        level (str): Logging level (INFO, WARNING, ERROR, DEBUG)
    """
    print(f"[{level}] {message}")

# For large dataset handling
try:
    import dask.dataframe as dd
    DASK_AVAILABLE = True
except ImportError:
    DASK_AVAILABLE = False

# For advanced imputation
try:
    from sklearn.impute import SimpleImputer, KNNImputer
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


def identify_data_issues(df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    """
    Identify data quality issues in a DataFrame.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        
    Returns:
        Dict[str, Dict[str, Any]]: Dictionary of issues by column
    """
    log_action("Identifying data issues")
    
    issues = {}
    
    # Check each column for issues
    for column in df.columns:
        column_issues = {}
        
        # Check for missing values
        missing_count = df[column].isnull().sum()
        missing_percent = (missing_count / len(df)) * 100
        if missing_count > 0:
            column_issues['missing_values'] = {
                'count': int(missing_count),
                'percent': float(missing_percent)
            }
        
        # Analyze data type and potential issues
        dtype = df[column].dtype
        column_issues['data_type'] = str(dtype)
        
        # For numeric columns
        if pd.api.types.is_numeric_dtype(df[column]):
            # Check for zeros (might be placeholders for missing data)
            zero_count = (df[column] == 0).sum()
            if zero_count > 0:
                column_issues['zeros'] = {
                    'count': int(zero_count),
                    'percent': float((zero_count / len(df)) * 100)
                }
            
            # Check for negative values (might be invalid in certain contexts)
            if df[column].min() < 0:
                neg_count = (df[column] < 0).sum()
                column_issues['negative_values'] = {
                    'count': int(neg_count),
                    'percent': float((neg_count / len(df)) * 100)
                }
            
            # Check for outliers using IQR method
            q1 = df[column].quantile(0.25)
            q3 = df[column].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - (1.5 * iqr)
            upper_bound = q3 + (1.5 * iqr)
            outliers = df[(df[column] < lower_bound) | (df[column] > upper_bound)]
            if len(outliers) > 0:
                column_issues['outliers'] = {
                    'count': len(outliers),
                    'percent': float((len(outliers) / len(df)) * 100),
                    'lower_bound': float(lower_bound),
                    'upper_bound': float(upper_bound)
                }
        
        # For string/object columns
        elif pd.api.types.is_string_dtype(df[column]) or df[column].dtype == 'object':
            # Check for empty strings
            if df[column].dtype == 'object':
                empty_strings = (df[column] == '').sum()
                if empty_strings > 0:
                    column_issues['empty_strings'] = {
                        'count': int(empty_strings),
                        'percent': float((empty_strings / len(df)) * 100)
                    }
                
                # Check for whitespace-only strings
                if isinstance(df[column].iloc[0], str):
                    whitespace = df[column].str.isspace().sum()
                    if whitespace > 0:
                        column_issues['whitespace_strings'] = {
                            'count': int(whitespace),
                            'percent': float((whitespace / len(df)) * 100)
                        }
                
                # Check for mixed casing (potential inconsistency)
                try:
                    lowercase = df[column].str.islower().sum()
                    uppercase = df[column].str.isupper().sum()
                    if lowercase > 0 and uppercase > 0:
                        column_issues['mixed_case'] = {
                            'lowercase_count': int(lowercase),
                            'uppercase_count': int(uppercase)
                        }
                except:
                    # Skip if string operations fail (non-string objects in column)
                    pass
                
                # Check for inconsistent formats (e.g., dates, phone numbers, etc.)
                # This is a simplified check, can be extended based on specific needs
                try:
                    # Only proceed if all values are strings
                    if df[column].dropna().apply(lambda x: isinstance(x, str)).all():
                        unique_lengths = df[column].str.len().nunique()
                        if unique_lengths > 3:  # Arbitrary threshold
                            column_issues['inconsistent_formats'] = {
                                'unique_lengths': int(unique_lengths)
                            }
                except:
                    # Skip if operation fails
                    pass
        
        # For datetime columns
        elif pd.api.types.is_datetime64_dtype(df[column]):
            # Check for dates in the future (might be invalid)
            now = pd.Timestamp.now()
            future_dates = (df[column] > now).sum()
            if future_dates > 0:
                column_issues['future_dates'] = {
                    'count': int(future_dates),
                    'percent': float((future_dates / len(df)) * 100)
                }
            
            # Check for very old dates (might be invalid)
            old_threshold = pd.Timestamp('1900-01-01')
            old_dates = (df[column] < old_threshold).sum()
            if old_dates > 0:
                column_issues['very_old_dates'] = {
                    'count': int(old_dates),
                    'percent': float((old_dates / len(df)) * 100)
                }
        
        # Add issues for this column to the main dictionary
        if len(column_issues) > 1:  # More than just data_type
            issues[column] = column_issues
    
    return issues


def get_data_quality_report(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Generate a comprehensive data quality report.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        
    Returns:
        Dict[str, Any]: Data quality report
    """
    log_action("Generating data quality report")
    
    report = {
        'row_count': len(df),
        'column_count': len(df.columns),
        'memory_usage': df.memory_usage(deep=True).sum() / (1024 * 1024),  # in MB
        'column_details': {},
        'missing_data': {
            'total_missing_cells': df.isnull().sum().sum(),
            'total_cells': df.size,
            'percent_missing': (df.isnull().sum().sum() / df.size) * 100
        },
        'duplicate_rows': {
            'count': df.duplicated().sum(),
            'percent': (df.duplicated().sum() / len(df)) * 100
        }
    }
    
    # Get column-specific details
    for column in df.columns:
        col_data = {
            'dtype': str(df[column].dtype),
            'missing_count': int(df[column].isnull().sum()),
            'missing_percent': float((df[column].isnull().sum() / len(df)) * 100),
            'unique_count': int(df[column].nunique()),
            'unique_percent': float((df[column].nunique() / len(df)) * 100)
        }
        
        # For numeric columns
        if pd.api.types.is_numeric_dtype(df[column]):
            valid_data = df[column].dropna()
            if len(valid_data) > 0:
                col_data.update({
                    'min': float(valid_data.min()),
                    'max': float(valid_data.max()),
                    'mean': float(valid_data.mean()),
                    'median': float(valid_data.median()),
                    'std_dev': float(valid_data.std()),
                    'zeros_count': int((valid_data == 0).sum()),
                    'zeros_percent': float(((valid_data == 0).sum() / len(df)) * 100)
                })
        
        # For string/object columns
        elif pd.api.types.is_string_dtype(df[column]) or df[column].dtype == 'object':
            try:
                valid_data = df[column].dropna()
                if len(valid_data) > 0:
                    # Length statistics
                    if valid_data.apply(lambda x: isinstance(x, str)).all():
                        lengths = valid_data.str.len()
                        col_data.update({
                            'min_length': int(lengths.min()),
                            'max_length': int(lengths.max()),
                            'mean_length': float(lengths.mean())
                        })
                    
                    # Most common value
                    most_common = valid_data.value_counts().nlargest(1)
                    if len(most_common) > 0:
                        col_data.update({
                            'most_common_value': str(most_common.index[0]),
                            'most_common_count': int(most_common.iloc[0]),
                            'most_common_percent': float((most_common.iloc[0] / len(df)) * 100)
                        })
            except:
                # Skip if operations fail
                pass
        
        # For datetime columns
        elif pd.api.types.is_datetime64_dtype(df[column]):
            valid_data = df[column].dropna()
            if len(valid_data) > 0:
                col_data.update({
                    'min_date': valid_data.min().strftime('%Y-%m-%d'),
                    'max_date': valid_data.max().strftime('%Y-%m-%d'),
                    'range_days': (valid_data.max() - valid_data.min()).days
                })
        
        report['column_details'][column] = col_data
    
    return report


def suggest_cleaning_strategy(df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    """
    Suggest cleaning strategies based on data quality issues.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        
    Returns:
        Dict[str, Dict[str, Any]]: Suggested cleaning strategies by column
    """
    log_action("Suggesting cleaning strategies")
    
    # Get data issues first
    issues = identify_data_issues(df)
    strategies = {}
    
    # For each column with issues, suggest appropriate strategies
    for column, column_issues in issues.items():
        col_strategies = {}
        
        # Strategy for missing values
        if 'missing_values' in column_issues:
            missing_percent = column_issues['missing_values']['percent']
            dtype = df[column].dtype
            
            # Different strategies based on missing percentage and data type
            if missing_percent > 80:
                # Too many missing values, might be better to drop the column
                col_strategies['missing_values'] = {
                    'strategy': 'drop_column',
                    'reason': f"Column has {missing_percent:.1f}% missing values, which might indicate irrelevant data"
                }
            elif pd.api.types.is_numeric_dtype(df[column]):
                # For numeric data
                if missing_percent < 5:
                    col_strategies['missing_values'] = {
                        'strategy': 'impute_mean',
                        'reason': "Small percentage of missing values, can be imputed with mean"
                    }
                elif missing_percent < 20:
                    col_strategies['missing_values'] = {
                        'strategy': 'impute_median',
                        'reason': "Moderate percentage of missing values, median imputation is more robust to outliers"
                    }
                else:
                    # For higher percentages, consider KNN imputation or model-based methods
                    col_strategies['missing_values'] = {
                        'strategy': 'impute_knn' if SKLEARN_AVAILABLE else 'impute_median',
                        'reason': "High percentage of missing values, advanced imputation recommended"
                    }
            elif pd.api.types.is_string_dtype(df[column]) or df[column].dtype == 'object':
                # For categorical/string data
                if missing_percent < 10:
                    col_strategies['missing_values'] = {
                        'strategy': 'impute_mode',
                        'reason': "Can be imputed with the most frequent value"
                    }
                else:
                    col_strategies['missing_values'] = {
                        'strategy': 'impute_missing_category',
                        'reason': "High percentage of missing values, treat as its own category"
                    }
            elif pd.api.types.is_datetime64_dtype(df[column]):
                # For datetime data
                col_strategies['missing_values'] = {
                    'strategy': 'impute_mode',
                    'reason': "Impute with most common date or consider forward/backward fill if sequential"
                }
        
        # Strategy for outliers
        if 'outliers' in column_issues:
            outlier_percent = column_issues['outliers']['percent']
            
            if outlier_percent < 1:
                # Very few outliers
                col_strategies['outliers'] = {
                    'strategy': 'cap_outliers',
                    'reason': "Few outliers, can be capped at IQR boundaries"
                }
            elif outlier_percent < 5:
                # Moderate number of outliers
                col_strategies['outliers'] = {
                    'strategy': 'winsorize',
                    'reason': "Moderate outliers, winsorize to reduce impact"
                }
            else:
                # Many outliers - might not be true outliers but a different distribution
                col_strategies['outliers'] = {
                    'strategy': 'transform_log',
                    'reason': "Many outliers, consider log transformation or robust scaling"
                }
        
        # Strategy for inconsistent formats (string columns)
        if 'inconsistent_formats' in column_issues:
            # Check if the column might contain structured data like dates, emails, phone numbers
            sample_values = df[column].dropna().sample(min(10, df[column].count())).astype(str).tolist()
            
            # Check for potential date patterns
            date_pattern = re.compile(r'\d{1,4}[/-]\d{1,2}[/-]\d{1,4}')
            potential_dates = [bool(date_pattern.search(str(val))) for val in sample_values]
            
            # Check for email patterns
            email_pattern = re.compile(r'[^@]+@[^@]+\.[^@]+')
            potential_emails = [bool(email_pattern.match(str(val))) for val in sample_values]
            
            if sum(potential_dates) > len(sample_values) / 2:
                col_strategies['inconsistent_formats'] = {
                    'strategy': 'standardize_dates',
                    'reason': "Column might contain dates in inconsistent formats"
                }
            elif sum(potential_emails) > len(sample_values) / 2:
                col_strategies['inconsistent_formats'] = {
                    'strategy': 'validate_emails',
                    'reason': "Column might contain email addresses, validate format"
                }
            else:
                col_strategies['inconsistent_formats'] = {
                    'strategy': 'standardize_text',
                    'reason': "Standardize text formatting (case, whitespace, etc.)"
                }
        
        # Strategy for mixed case
        if 'mixed_case' in column_issues:
            col_strategies['mixed_case'] = {
                'strategy': 'lowercase_all',
                'reason': "Standardize case to lowercase for consistency"
            }
        
        # Strategy for zeros (potentially missing values coded as zeros)
        if 'zeros' in column_issues and column_issues['zeros']['percent'] > 10:
            col_strategies['zeros'] = {
                'strategy': 'review_zeros',
                'reason': "High percentage of zeros, may represent missing values"
            }
        
        # Strategy for negative values (potentially errors)
        if 'negative_values' in column_issues and column_issues['negative_values']['percent'] > 0:
            col_strategies['negative_values'] = {
                'strategy': 'review_negatives',
                'reason': "Negative values found, might be invalid for this data type"
            }
        
        # Add strategies for this column to the main dictionary
        if col_strategies:
            strategies[column] = col_strategies
    
    return strategies


def clean_data(df: pd.DataFrame, cleaning_settings: Dict[str, Any] = None) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Clean data based on provided settings or auto-detected issues.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        cleaning_settings (Dict[str, Any], optional): Cleaning settings. If None, 
                                                    auto-detect and apply basic cleaning.
    
    Returns:
        Tuple[pd.DataFrame, Dict[str, Any]]: Cleaned DataFrame and cleaning log
    """
    log_action("Starting data cleaning process")
    
    # Create a copy of the dataframe to avoid modifying the original
    cleaned_df = df.copy()
    
    # Initialize cleaning log
    cleaning_log = {
        'operations_by_column': {},
        'rows_before': len(df),
        'columns_before': len(df.columns),
        'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    }
    
    # If no cleaning settings provided, auto-detect issues and get strategies
    if cleaning_settings is None or cleaning_settings == {}:
        strategies = suggest_cleaning_strategy(df)
        cleaning_settings = {
            'auto_detected': True,
            'strategies': strategies
        }
    
    # Process each column according to settings
    for column in cleaned_df.columns:
        column_log = []
        
        # Skip columns not in cleaning settings
        if 'strategies' not in cleaning_settings or column not in cleaning_settings['strategies']:
            continue
        
        column_strategies = cleaning_settings['strategies'][column]
        
        # Handle missing values
        if 'missing_values' in column_strategies:
            strategy = column_strategies['missing_values']['strategy']
            
            if strategy == 'drop_column':
                cleaned_df = cleaned_df.drop(columns=[column])
                column_log.append(f"Dropped column due to excessive missing values ({column_strategies['missing_values'].get('percent', 'N/A')}%)")
                # Skip further processing for this column
                cleaning_log['operations_by_column'][column] = column_log
                continue
                
            elif strategy == 'impute_mean':
                mean_val = df[column].mean()
                cleaned_df[column] = cleaned_df[column].fillna(mean_val)
                column_log.append(f"Filled {df[column].isna().sum()} missing values with mean ({mean_val:.4f})")
                
            elif strategy == 'impute_median':
                median_val = df[column].median()
                cleaned_df[column] = cleaned_df[column].fillna(median_val)
                column_log.append(f"Filled {df[column].isna().sum()} missing values with median ({median_val:.4f})")
                
            elif strategy == 'impute_mode':
                mode_val = df[column].mode()[0]
                cleaned_df[column] = cleaned_df[column].fillna(mode_val)
                column_log.append(f"Filled {df[column].isna().sum()} missing values with mode ({mode_val})")
                
            elif strategy == 'impute_missing_category':
                if pd.api.types.is_string_dtype(df[column]) or df[column].dtype == 'object':
                    cleaned_df[column] = cleaned_df[column].fillna('Missing')
                    column_log.append(f"Filled {df[column].isna().sum()} missing values with 'Missing' category")
                
            elif strategy == 'impute_knn' and SKLEARN_AVAILABLE:
                # KNN imputation requires multiple columns and handling non-numeric data
                # This is a simplified implementation
                try:
                    # Select only numeric columns for KNN imputation
                    numeric_cols = cleaned_df.select_dtypes(include=['number']).columns.tolist()
                    if column in numeric_cols and len(numeric_cols) > 1:
                        # Standardize the data for KNN
                        scaler = StandardScaler()
                        imputer = KNNImputer(n_neighbors=5)
                        
                        # Fit and transform
                        numeric_data = cleaned_df[numeric_cols].copy()
                        numeric_data_scaled = scaler.fit_transform(numeric_data)
                        imputed_data_scaled = imputer.fit_transform(numeric_data_scaled)
                        
                        # Get the imputed column and rescale
                        col_idx = numeric_cols.index(column)
                        imputed_col_scaled = imputed_data_scaled[:, col_idx]
                        imputed_col = scaler.inverse_transform(
                            np.zeros((len(imputed_col_scaled), len(numeric_cols)))
                        )[:, col_idx]
                        
                        # Update only the missing values
                        missing_mask = cleaned_df[column].isna()
                        cleaned_df.loc[missing_mask, column] = imputed_col[missing_mask]
                        column_log.append(f"Filled {missing_mask.sum()} missing values with KNN imputation")
                    else:
                        # Fall back to median imputation
                        median_val = df[column].median()
                        cleaned_df[column] = cleaned_df[column].fillna(median_val)
                        column_log.append(f"Filled {df[column].isna().sum()} missing values with median ({median_val:.4f}) - KNN not applicable")
                except Exception as e:
                    # If KNN fails, fall back to median
                    median_val = df[column].median()
                    cleaned_df[column] = cleaned_df[column].fillna(median_val)
                    column_log.append(f"Filled {df[column].isna().sum()} missing values with median ({median_val:.4f}) - KNN failed: {str(e)}")
        
        # Handle outliers
        if 'outliers' in column_strategies:
            strategy = column_strategies['outliers']['strategy']
            
            # Calculate IQR bounds
            q1 = df[column].quantile(0.25)
            q3 = df[column].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - (1.5 * iqr)
            upper_bound = q3 + (1.5 * iqr)
            
            if strategy == 'cap_outliers':
                # Count outliers before capping
                outliers_count = ((cleaned_df[column] < lower_bound) | (cleaned_df[column] > upper_bound)).sum()
                
                # Apply capping
                cleaned_df[column] = cleaned_df[column].clip(lower=lower_bound, upper=upper_bound)
                column_log.append(f"Capped {outliers_count} outliers to IQR bounds ({lower_bound:.4f}, {upper_bound:.4f})")
                
            elif strategy == 'winsorize':
                # Winsorizing is similar to capping but using percentiles
                winsor_lower = df[column].quantile(0.05)
                winsor_upper = df[column].quantile(0.95)
                
                # Count outliers before winsorizing
                outliers_count = ((cleaned_df[column] < winsor_lower) | (cleaned_df[column] > winsor_upper)).sum()
                
                # Apply winsorizing
                cleaned_df[column] = cleaned_df[column].clip(lower=winsor_lower, upper=winsor_upper)
                column_log.append(f"Winsorized {outliers_count} values to 5th-95th percentiles ({winsor_lower:.4f}, {winsor_upper:.4f})")
                
            elif strategy == 'transform_log':
                if (cleaned_df[column] > 0).all():
                    # Log transform only works for positive values
                    cleaned_df[column] = np.log1p(cleaned_df[column])
                    column_log.append(f"Applied log(x+1) transformation to reduce impact of outliers")
                else:
                    # If negative values exist, shift data before log transform
                    min_val = cleaned_df[column].min()
                    if min_val <= 0:
                        shift = abs(min_val) + 1
                        cleaned_df[column] = np.log1p(cleaned_df[column] + shift)
                        column_log.append(f"Applied log(x+{shift:.4f}) transformation to reduce impact of outliers")
        
        # Handle inconsistent formats
        if 'inconsistent_formats' in column_strategies:
            strategy = column_strategies['inconsistent_formats']['strategy']
            
            if strategy == 'standardize_dates':
                # Attempt to convert to datetime
                try:
                    # Note the original format count
                    original_unique_formats = cleaned_df[column].apply(lambda x: str(x)).nunique()
                    
                    # Try to parse dates
                    cleaned_df[column] = pd.to_datetime(cleaned_df[column], errors='coerce')
                    
                    # Count how many were successfully converted
                    success_count = cleaned_df[column].notna().sum()
                    fail_count = cleaned_df[column].isna().sum()
                    
                    column_log.append(f"Standardized dates: {success_count} converted, {fail_count} failed")
                except Exception as e:
                    column_log.append(f"Failed to standardize dates: {str(e)}")
            
            elif strategy == 'validate_emails':
                # Validate and clean email addresses
                email_pattern = re.compile(r'[^@]+@[^@]+\.[^@]+')
                
                # Function to validate and clean emails
                def clean_email(val):
                    if pd.isna(val):
                        return val
                    
                    # Convert to string
                    val = str(val).strip().lower()
                    
                    # Check if it's a valid email
                    if email_pattern.match(val):
                        return val
                    else:
                        return np.nan
                
                # Apply cleaning
                cleaned_df[column] = cleaned_df[column].apply(clean_email)
                
                # Count valid and invalid emails
                valid_count = cleaned_df[column].notna().sum()
                invalid_count = cleaned_df[column].isna().sum() - df[column].isna().sum()
                
                column_log.append(f"Validated emails: {valid_count} valid, {invalid_count} invalid")
            
            elif strategy == 'standardize_text':
                # Basic text standardization
                if cleaned_df[column].dtype == 'object':
                    # Function to standardize text
                    def standardize_text(val):
                        if pd.isna(val):
                            return val
                        
                        # Convert to string, strip whitespace, and convert to lowercase
                        return str(val).strip().lower()
                    
                    # Apply standardization
                    cleaned_df[column] = cleaned_df[column].apply(standardize_text)
                    column_log.append(f"Standardized text formatting (whitespace removed, converted to lowercase)")
        
        # Handle mixed case
        if 'mixed_case' in column_strategies and column_strategies['mixed_case']['strategy'] == 'lowercase_all':
            if cleaned_df[column].dtype == 'object':
                # Convert to lowercase
                cleaned_df[column] = cleaned_df[column].str.lower()
                column_log.append("Converted all values to lowercase")
        
        # Handle zeros
        if 'zeros' in column_strategies and column_strategies['zeros']['strategy'] == 'review_zeros':
            # Check if zeros are significant based on context (e.g., age shouldn't be 0)
            zero_count = (cleaned_df[column] == 0).sum()
            
            # Log the finding but don't automatically change the values
            column_log.append(f"Identified {zero_count} zero values that may represent missing data (review recommended)")
        
        # Handle negative values
        if 'negative_values' in column_strategies and column_strategies['negative_values']['strategy'] == 'review_negatives':
            neg_count = (cleaned_df[column] < 0).sum()
            
            # Log the finding but don't automatically change the values
            column_log.append(f"Identified {neg_count} negative values that may be invalid (review recommended)")
        
        # Record all operations for this column
        if column_log:
            cleaning_log['operations_by_column'][column] = column_log
    
    # Record final stats
    cleaning_log['rows_after'] = len(cleaned_df)
    cleaning_log['columns_after'] = len(cleaned_df.columns)
    cleaning_log['end_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # Calculate overall changes
    cleaning_log['rows_removed'] = cleaning_log['rows_before'] - cleaning_log['rows_after']
    cleaning_log['columns_removed'] = cleaning_log['columns_before'] - cleaning_log['columns_after']
    
    # Log completion
    log_action(f"Data cleaning completed: {len(cleaning_log['operations_by_column'])} columns modified")
    
    return cleaned_df, cleaning_log


def auto_clean_data(df: pd.DataFrame, aggressiveness: str = 'moderate') -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Automatically clean data with different levels of aggressiveness.
    
    Args:
        df (pd.DataFrame): Input DataFrame
        aggressiveness (str): Level of cleaning aggressiveness: 'minimal', 'moderate', or 'aggressive'
        
    Returns:
        Tuple[pd.DataFrame, Dict[str, Any]]: Cleaned DataFrame and cleaning log
    """
    log_action(f"Starting auto-cleaning with {aggressiveness} aggressiveness")
    
    # Convert to dask dataframe for large datasets
    if DASK_AVAILABLE and len(df) > 100000:
        try:
            dask_df = dd.from_pandas(df, npartitions=max(1, len(df) // 100000))
            is_dask = True
        except:
            is_dask = False
    else:
        is_dask = False
    
    # Get data issues and suggested strategies
    strategies = suggest_cleaning_strategy(df)
    
    # Modify strategies based on aggressiveness level
    auto_cleaning_settings = {
        'auto_detected': True,
        'aggressiveness': aggressiveness,
        'strategies': {}
    }
    
    # For each column with suggested strategies
    for column, column_strategies in strategies.items():
        # Skip columns that are all missing
        if df[column].isna().all():
            continue
        
        # Initialize strategies for this column
        auto_cleaning_settings['strategies'][column] = {}
        
        # Handle missing values based on aggressiveness
        if 'missing_values' in column_strategies:
            missing_strategy = column_strategies['missing_values']
            missing_percent = df[column].isna().sum() / len(df) * 100
            
            if aggressiveness == 'minimal':
                # Only handle columns with few missing values
                if missing_percent < 5:
                    auto_cleaning_settings['strategies'][column]['missing_values'] = missing_strategy
            elif aggressiveness == 'moderate':
                # Handle columns with moderate missing values
                if missing_percent < 30:
                    auto_cleaning_settings['strategies'][column]['missing_values'] = missing_strategy
            else:  # aggressive
                # Handle all columns with missing values
                auto_cleaning_settings['strategies'][column]['missing_values'] = missing_strategy
        
        # Handle outliers based on aggressiveness
        if 'outliers' in column_strategies:
            outlier_strategy = column_strategies['outliers']
            
            if aggressiveness == 'minimal':
                # Only cap extreme outliers
                outlier_strategy['strategy'] = 'cap_outliers'
                auto_cleaning_settings['strategies'][column]['outliers'] = outlier_strategy
            elif aggressiveness == 'moderate':
                # Use suggested strategy
                auto_cleaning_settings['strategies'][column]['outliers'] = outlier_strategy
            else:  # aggressive
                # Always use winsorizing for aggressive mode
                outlier_strategy['strategy'] = 'winsorize'
                auto_cleaning_settings['strategies'][column]['outliers'] = outlier_strategy
        
        # Handle inconsistent formats
        if 'inconsistent_formats' in column_strategies:
            format_strategy = column_strategies['inconsistent_formats']
            
            if aggressiveness == 'minimal':
                # Only standardize text
                if format_strategy['strategy'] == 'standardize_text':
                    auto_cleaning_settings['strategies'][column]['inconsistent_formats'] = format_strategy
            else:  # moderate or aggressive
                # Apply all format standardization
                auto_cleaning_settings['strategies'][column]['inconsistent_formats'] = format_strategy
        
        # Handle mixed case (only in moderate or aggressive modes)
        if 'mixed_case' in column_strategies and aggressiveness != 'minimal':
            auto_cleaning_settings['strategies'][column]['mixed_case'] = column_strategies['mixed_case']
    
    # Additional aggressive cleaning options
    if aggressiveness == 'aggressive':
        # Drop columns with > 80% missing
        for column in df.columns:
            missing_percent = df[column].isna().sum() / len(df) * 100
            if missing_percent > 80:
                if column not in auto_cleaning_settings['strategies']:
                    auto_cleaning_settings['strategies'][column] = {}
                
                auto_cleaning_settings['strategies'][column]['missing_values'] = {
                    'strategy': 'drop_column',
                    'reason': f"Column has {missing_percent:.1f}% missing values, automatically dropped in aggressive mode"
                }
    
    # Apply cleaning settings
    if is_dask:
        # For dask dataframe, convert back to pandas for cleaning
        # (Many cleaning operations are not supported in dask)
        cleaned_df, cleaning_log = clean_data(df, auto_cleaning_settings)
    else:
        # For pandas dataframe, clean directly
        cleaned_df, cleaning_log = clean_data(df, auto_cleaning_settings)
    
    # Add auto-cleaning metadata to log
    cleaning_log['auto_cleaning'] = {
        'aggressiveness': aggressiveness,
        'columns_detected': len(strategies),
        'columns_cleaned': len(cleaning_log['operations_by_column'])
    }
    
    return cleaned_df, cleaning_log


# Main execution (for testing purposes)
if __name__ == "__main__":
    # Create sample DataFrame
    data = {
        'age': [25, 30, np.nan, 40, 35, 999, 28, np.nan],
        'income': [50000, 60000, 75000, np.nan, 65000, 55000, np.nan, 80000],
        'email': ['user@example.com', 'invalid', np.nan, 'test@test.com', 'another@example.com', '', 'USER@EXAMPLE.COM', np.nan],
        'date_joined': ['2020-01-15', '01/20/2020', np.nan, '2020/03/01', '2020-04-15', '01-05-2020', np.nan, '2050-01-01']
    }
    df = pd.DataFrame(data)
    
    # Auto-clean with moderate aggressiveness
    cleaned_df, cleaning_log = auto_clean_data(df, aggressiveness='moderate')
    
    # Print results
    print("Original DataFrame:")
    print(df)
    print("\nCleaned DataFrame:")
    print(cleaned_df)
    print("\nCleaning Log:")
    for column, operations in cleaning_log['operations_by_column'].items():
        print(f"\n{column}:")
        for op in operations:
            print(f"  - {op}")
