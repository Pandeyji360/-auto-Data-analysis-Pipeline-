#!/bin/bash
# Run script for the Automated Data Analysis Pipeline application

# Change to the script directory
cd "$(dirname "$0")"

# Run the application
python main.py