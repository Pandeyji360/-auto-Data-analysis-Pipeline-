#!/usr/bin/env python3
"""
Streamlit Web Application for Data Analysis Pipeline
--------------------------------------------------
This script implements a Streamlit web interface for the data analysis pipeline,
allowing users to upload, analyze, visualize, and clean datasets.

Author: Senior Data Engineer
Date: May 5, 2025
Version: 1.1
"""

import os
import sys
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import io
import base64
from datetime import datetime
import time
import json
from typing import Dict, List, Tuple, Union, Any, Optional

# Import from our modules
from data_cleaning import (
    identify_data_issues,
    get_data_quality_report,
    suggest_cleaning_strategy,
    clean_data,
    auto_clean_data
)
from auto_cleaning import (
    analyze_and_suggest,
    perform_auto_cleaning,
    compare_cleaning_options,
    generate_cleaning_preview
)
from utils import (
    get_data_summary,
    convert_df_to_csv,
    get_file_size,
    is_large_file,
    get_memory_usage,
    infer_encoding,
    determine_delimiter
)
# Define local logger functions if logger module is not available
def setup_logger():
    """Set up a logger with appropriate formatting and output."""
    import logging
    logger = logging.getLogger("data_pipeline")
    logger.setLevel(logging.INFO)
    
    # Add console handler if not already added
    if not logger.handlers:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    return logger

def log_action(message, level="INFO"):
    """Log an action with the specified level."""
    import logging
    logger = logging.getLogger("data_pipeline")
    
    if level == "INFO":
        logger.info(message)
    elif level == "WARNING":
        logger.warning(message)
    elif level == "ERROR":
        logger.error(message)
    elif level == "DEBUG":
        logger.debug(message)

def get_logs(n=None):
    """Get the latest n log entries."""
    return []  # Simplified version

# Configure the app
st.set_page_config(
    page_title="Data Analysis Pipeline",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Set up logger
logger = setup_logger()

# Function to initialize session state
def initialize_session_state():
    if 'uploaded_files' not in st.session_state:
        st.session_state.uploaded_files = {}
    
    if 'current_file' not in st.session_state:
        st.session_state.current_file = None
    
    if 'current_df' not in st.session_state:
        st.session_state.current_df = None
    
    if 'cleaned_df' not in st.session_state:
        st.session_state.cleaned_df = None
    
    if 'cleaning_log' not in st.session_state:
        st.session_state.cleaning_log = None
    
    if 'issues_detected' not in st.session_state:
        st.session_state.issues_detected = None
    
    if 'auto_cleaning_preview' not in st.session_state:
        st.session_state.auto_cleaning_preview = None


# Initialize session state
initialize_session_state()


# ----------------- Page Header -----------------
st.title("Automated Data Analysis Pipeline")
st.markdown("""
This application provides powerful tools for data cleaning, visualization, and analysis.
Upload your dataset and explore tools for automatic data quality improvements.
""")


# ----------------- Sidebar Content -----------------
with st.sidebar:
    st.header("Data Management")
    
    # File uploader
    uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])
    
    if uploaded_file is not None:
        # Check if file is already uploaded
        if uploaded_file.name not in st.session_state.uploaded_files:
            try:
                # Read file size
                file_size = get_file_size(uploaded_file)
                
                # Check if file is large
                is_large = is_large_file(uploaded_file, threshold_mb=100)
                
                # Load using appropriate method
                if is_large and 'dask' in sys.modules:
                    st.info(f"Large file detected ({file_size}). Using Dask for processing.")
                    # Save to temporary file for Dask to read
                    temp_file_path = f"temp_{uploaded_file.name}"
                    with open(temp_file_path, "wb") as f:
                        f.write(uploaded_file.getbuffer())
                    
                    # Load with Dask
                    import dask.dataframe as dd
                    df = dd.read_csv(temp_file_path)
                    df_sample = df.head(1000)  # Get sample for display
                    
                    # Store in session state
                    st.session_state.uploaded_files[uploaded_file.name] = {
                        'df': df,
                        'df_sample': df_sample,
                        'file_size': file_size,
                        'is_large': True,
                        'temp_path': temp_file_path
                    }
                else:
                    # Regular pandas for normal sized files
                    df = pd.read_csv(uploaded_file)
                    
                    # Store in session state
                    st.session_state.uploaded_files[uploaded_file.name] = {
                        'df': df,
                        'file_size': file_size,
                        'is_large': False
                    }
                
                # Set as current file
                st.session_state.current_file = uploaded_file.name
                st.session_state.current_df = df
                
                st.success(f"File uploaded: {uploaded_file.name} ({file_size})")
                log_action(f"File uploaded: {uploaded_file.name} ({file_size})")
            
            except Exception as e:
                st.error(f"Error loading file: {str(e)}")
                log_action(f"Error loading file: {str(e)}", level="ERROR")
        else:
            st.info(f"File already loaded: {uploaded_file.name}")
            # Set as current file
            st.session_state.current_file = uploaded_file.name
            st.session_state.current_df = st.session_state.uploaded_files[uploaded_file.name]['df']
    
    # Display list of uploaded files
    if st.session_state.uploaded_files:
        st.write("Uploaded Files:")
        
        for filename, file_info in st.session_state.uploaded_files.items():
            col1, col2 = st.columns([3, 1])
            with col1:
                if st.button(f"📄 {filename}", key=f"select_{filename}"):
                    st.session_state.current_file = filename
                    st.session_state.current_df = file_info['df']
                    st.session_state.cleaned_df = None  # Reset cleaned data
                    st.session_state.cleaning_log = None  # Reset cleaning log
                    st.session_state.issues_detected = None  # Reset issues
                    st.rerun()
            
            with col2:
                st.write(file_info['file_size'])
    
    # Memory usage info
    st.subheader("Memory Usage")
    mem_usage = get_memory_usage()
    st.write(f"Current memory: {mem_usage['memory_usage']}")
    
    # Display current file information
    if st.session_state.current_file:
        st.subheader("Active Dataset")
        st.write(f"File: {st.session_state.current_file}")
        
        file_info = st.session_state.uploaded_files[st.session_state.current_file]
        df = st.session_state.current_df
        
        # Show dataframe info
        st.write(f"Rows: {len(df):,}")
        st.write(f"Columns: {len(df.columns):,}")
        st.write(f"Size: {file_info['file_size']}")
        
        # Allow clearing current file
        if st.button("Clear Current File"):
            st.session_state.current_file = None
            st.session_state.current_df = None
            st.session_state.cleaned_df = None
            st.session_state.cleaning_log = None
            st.session_state.issues_detected = None
            st.rerun()


# ----------------- Main Content -----------------
# Create tabs
tabs = st.tabs([
    "Data Overview", 
    "Data Quality Analysis", 
    "Data Cleaning", 
    "Auto-Clean", 
    "Visualization", 
    "Multi-File Analysis",
    "Processing Logs"
])


# ----------------- Tab 1: Data Overview -----------------
with tabs[0]:
    st.header("Data Overview")
    
    if st.session_state.current_df is not None:
        df = st.session_state.current_df
        
        # Display dataset info
        st.subheader("Dataset Information")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Rows", f"{len(df):,}")
        with col2:
            st.metric("Columns", f"{len(df.columns):,}")
        with col3:
            mem_usage = df.memory_usage(deep=True).sum() / (1024 * 1024)
            st.metric("Memory Usage", f"{mem_usage:.2f} MB")
        
        # Display column list
        st.subheader("Column List")
        
        # Organize columns by data type
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        datetime_cols = df.select_dtypes(include=['datetime']).columns.tolist()
        object_cols = df.select_dtypes(include=['object']).columns.tolist()
        other_cols = [col for col in df.columns if col not in numeric_cols + datetime_cols + object_cols]
        
        col1, col2 = st.columns(2)
        
        with col1:
            if numeric_cols:
                st.write("Numeric Columns:")
                for col in numeric_cols:
                    missing = df[col].isna().sum()
                    missing_pct = (missing / len(df)) * 100
                    st.write(f"- {col} ({missing_pct:.1f}% missing)")
            
            if datetime_cols:
                st.write("DateTime Columns:")
                for col in datetime_cols:
                    missing = df[col].isna().sum()
                    missing_pct = (missing / len(df)) * 100
                    st.write(f"- {col} ({missing_pct:.1f}% missing)")
        
        with col2:
            if object_cols:
                st.write("Text/Categorical Columns:")
                for col in object_cols:
                    missing = df[col].isna().sum()
                    missing_pct = (missing / len(df)) * 100
                    st.write(f"- {col} ({missing_pct:.1f}% missing)")
            
            if other_cols:
                st.write("Other Columns:")
                for col in other_cols:
                    missing = df[col].isna().sum()
                    missing_pct = (missing / len(df)) * 100
                    st.write(f"- {col} ({missing_pct:.1f}% missing)")
        
        # Data preview
        st.subheader("Data Preview")
        st.dataframe(df.head(10), use_container_width=True)
        
        # Data summary
        if st.checkbox("Show Detailed Data Summary"):
            with st.spinner("Generating data summary..."):
                summary = get_data_summary(df)
                st.dataframe(summary, use_container_width=True)
    else:
        st.info("Please upload a file or select one from the sidebar to view its details.")


# ----------------- Tab 2: Data Quality Analysis -----------------
with tabs[1]:
    st.header("Data Quality Analysis")
    
    if st.session_state.current_df is not None:
        df = st.session_state.current_df
        
        # Add button to perform analysis
        if st.button("Analyze Data Quality"):
            with st.spinner("Analyzing data quality..."):
                # Identify issues
                st.session_state.issues_detected = identify_data_issues(df)
                
                # Get quality report
                quality_report = get_data_quality_report(df)
                
                # Store in session state
                st.session_state.quality_report = quality_report
                
                # Update log
                log_action(f"Data quality analysis completed for {st.session_state.current_file}")
        
        # Display results if available
        if st.session_state.issues_detected is not None:
            st.subheader("Data Quality Issues")
            
            # Summary metrics
            col1, col2, col3 = st.columns(3)
            
            # Count columns with issues
            columns_with_issues = len(st.session_state.issues_detected)
            
            # Count total issues
            total_issues = sum(len(issues) - 1 for issues in st.session_state.issues_detected.values())  # -1 to exclude data_type
            
            # Calculate missing values
            total_missing = sum(
                issues['missing_values']['count'] 
                for col, issues in st.session_state.issues_detected.items() 
                if 'missing_values' in issues
            )
            
            with col1:
                st.metric("Columns with Issues", columns_with_issues)
            with col2:
                st.metric("Total Issues", total_issues)
            with col3:
                missing_percent = (total_missing / (len(df) * len(df.columns))) * 100
                st.metric("Missing Values", f"{total_missing:,} ({missing_percent:.1f}%)")
            
            # Display issues by column
            st.subheader("Issues by Column")
            
            for column, issues in st.session_state.issues_detected.items():
                with st.expander(f"{column} - {len(issues) - 1} issues"):  # -1 to exclude data_type
                    for issue_type, details in issues.items():
                        if issue_type != 'data_type':
                            st.write(f"**{issue_type.replace('_', ' ').title()}**")
                            
                            # Display issue details
                            for key, value in details.items():
                                if isinstance(value, float):
                                    st.write(f"- {key.replace('_', ' ').title()}: {value:.2f}")
                                else:
                                    st.write(f"- {key.replace('_', ' ').title()}: {value}")
            
            # Display suggested cleaning strategies
            st.subheader("Suggested Cleaning Strategies")
            
            strategies = suggest_cleaning_strategy(df)
            
            for column, column_strategies in strategies.items():
                with st.expander(f"Strategies for {column}"):
                    for issue_type, strategy in column_strategies.items():
                        st.write(f"**{issue_type.replace('_', ' ').title()}**")
                        st.write(f"- Suggested action: {strategy['strategy'].replace('_', ' ').title()}")
                        st.write(f"- Reason: {strategy['reason']}")
            
            # Provide option to proceed to cleaning
            st.success("Data quality analysis complete. You can now proceed to the Data Cleaning tab to address these issues.")
            
            if st.button("Proceed to Data Cleaning"):
                # Switch to the cleaning tab
                pass
                
        else:
            st.info("Click 'Analyze Data Quality' to identify issues in your dataset.")
    else:
        st.info("Please upload a file or select one from the sidebar to analyze its quality.")


# ----------------- Tab 3: Data Cleaning -----------------
with tabs[2]:
    st.header("Data Cleaning")
    
    if st.session_state.current_df is not None:
        df = st.session_state.current_df
        
        # Check if analysis has been performed
        if st.session_state.issues_detected is None:
            st.warning("Please analyze data quality first (in the Data Quality Analysis tab).")
            if st.button("Analyze Data Now"):
                with st.spinner("Analyzing data quality..."):
                    # Identify issues
                    st.session_state.issues_detected = identify_data_issues(df)
                    # Get quality report
                    quality_report = get_data_quality_report(df)
                    # Store in session state
                    st.session_state.quality_report = quality_report
                    # Update log
                    log_action(f"Data quality analysis completed for {st.session_state.current_file}")
                st.rerun()
        else:
            # Display cleaning options
            st.subheader("Configure Cleaning Operations")
            
            # Get suggested strategies
            strategies = suggest_cleaning_strategy(df)
            
            # Create cleaning settings structure
            if 'cleaning_settings' not in st.session_state:
                st.session_state.cleaning_settings = {
                    'strategies': {}
                }
            
            # Show options for each column with issues
            for column, column_strategies in strategies.items():
                with st.expander(f"Cleaning options for {column}"):
                    if column not in st.session_state.cleaning_settings['strategies']:
                        st.session_state.cleaning_settings['strategies'][column] = {}
                    
                    # For each issue type, show strategy options
                    for issue_type, strategy in column_strategies.items():
                        st.write(f"**{issue_type.replace('_', ' ').title()}**")
                        st.write(f"Suggested: {strategy['strategy'].replace('_', ' ').title()}")
                        st.write(f"Reason: {strategy['reason']}")
                        
                        # Add options based on issue type
                        if issue_type == 'missing_values':
                            options = ['drop_column', 'impute_mean', 'impute_median', 'impute_mode', 
                                      'impute_constant', 'impute_knn', 'impute_missing_category']
                            
                            # Only show applicable options based on data type
                            if not pd.api.types.is_numeric_dtype(df[column]):
                                options = [opt for opt in options if opt not in ['impute_mean', 'impute_median', 'impute_knn']]
                            
                            selected = st.selectbox(
                                f"Choose strategy for missing values in {column}",
                                options,
                                index=options.index(strategy['strategy']) if strategy['strategy'] in options else 0,
                                key=f"missing_{column}"
                            )
                            
                            # Add extra options for some strategies
                            if selected == 'impute_constant':
                                const_val = st.text_input(
                                    "Constant value to use:", 
                                    key=f"const_{column}"
                                )
                                st.session_state.cleaning_settings['strategies'][column][issue_type] = {
                                    'strategy': selected,
                                    'constant_value': const_val
                                }
                            else:
                                st.session_state.cleaning_settings['strategies'][column][issue_type] = {
                                    'strategy': selected
                                }
                        
                        elif issue_type == 'outliers':
                            options = ['cap_outliers', 'winsorize', 'transform_log', 'drop_outliers']
                            
                            selected = st.selectbox(
                                f"Choose strategy for outliers in {column}",
                                options,
                                index=options.index(strategy['strategy']) if strategy['strategy'] in options else 0,
                                key=f"outliers_{column}"
                            )
                            
                            st.session_state.cleaning_settings['strategies'][column][issue_type] = {
                                'strategy': selected
                            }
                        
                        elif issue_type == 'inconsistent_formats':
                            options = ['standardize_text', 'standardize_dates', 'validate_emails']
                            
                            selected = st.selectbox(
                                f"Choose strategy for inconsistent formats in {column}",
                                options,
                                index=options.index(strategy['strategy']) if strategy['strategy'] in options else 0,
                                key=f"format_{column}"
                            )
                            
                            st.session_state.cleaning_settings['strategies'][column][issue_type] = {
                                'strategy': selected
                            }
                        
                        elif issue_type == 'mixed_case':
                            options = ['lowercase_all', 'uppercase_all', 'title_case']
                            
                            selected = st.selectbox(
                                f"Choose strategy for mixed case in {column}",
                                options,
                                index=options.index(strategy['strategy']) if strategy['strategy'] in options else 0,
                                key=f"case_{column}"
                            )
                            
                            st.session_state.cleaning_settings['strategies'][column][issue_type] = {
                                'strategy': selected
                            }
                        
                        else:
                            # For other issue types
                            st.session_state.cleaning_settings['strategies'][column][issue_type] = {
                                'strategy': strategy['strategy']
                            }
            
            # Button to apply cleaning
            if st.button("Apply Cleaning Operations"):
                with st.spinner("Cleaning data..."):
                    try:
                        # Apply cleaning operations
                        cleaned_df, cleaning_log = clean_data(df, st.session_state.cleaning_settings)
                        
                        # Store results in session state
                        st.session_state.cleaned_df = cleaned_df
                        st.session_state.cleaning_log = cleaning_log
                        
                        # Log action
                        log_action(f"Data cleaning completed for {st.session_state.current_file}")
                        
                        st.success("Data cleaning completed successfully!")
                    except Exception as e:
                        st.error(f"Error during data cleaning: {str(e)}")
                        log_action(f"Error during data cleaning: {str(e)}", level="ERROR")
            
            # Display cleaning results if available
            if st.session_state.cleaned_df is not None and st.session_state.cleaning_log is not None:
                st.subheader("Cleaning Results")
                
                # Show statistics
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    rows_removed = st.session_state.cleaning_log['rows_before'] - st.session_state.cleaning_log['rows_after']
                    st.metric("Rows Removed", rows_removed)
                
                with col2:
                    cols_removed = st.session_state.cleaning_log['columns_before'] - st.session_state.cleaning_log['columns_after']
                    st.metric("Columns Removed", cols_removed)
                
                with col3:
                    cols_modified = len(st.session_state.cleaning_log['operations_by_column'])
                    st.metric("Columns Modified", cols_modified)
                
                # Detailed log
                st.subheader("Cleaning Operations Log")
                
                for column, operations in st.session_state.cleaning_log['operations_by_column'].items():
                    with st.expander(f"Operations on {column}"):
                        for operation in operations:
                            st.write(f"- {operation}")
                
                # Compare original vs cleaned
                st.subheader("Original vs Cleaned Data")
                
                tab1, tab2 = st.tabs(["Original Data", "Cleaned Data"])
                
                with tab1:
                    st.dataframe(df.head(10), use_container_width=True)
                
                with tab2:
                    st.dataframe(st.session_state.cleaned_df.head(10), use_container_width=True)
                
                # Download cleaned data
                csv = convert_df_to_csv(st.session_state.cleaned_df)
                filename = f"cleaned_{st.session_state.current_file}"
                
                st.download_button(
                    "Download Cleaned Data",
                    csv,
                    filename,
                    "text/csv",
                    key='download-csv'
                )
    else:
        st.info("Please upload a file or select one from the sidebar to clean it.")


# ----------------- Tab 4: Auto-Clean -----------------
with tabs[3]:
    st.header("Automatic Data Cleaning")
    
    if st.session_state.current_df is not None:
        df = st.session_state.current_df
        
        st.markdown("""
        The Auto-Clean feature analyzes your data and applies intelligent cleaning operations automatically, 
        with different levels of aggressiveness:
        
        - **Minimal**: Conservative cleaning that preserves most data values
        - **Moderate**: Balanced approach that addresses common issues
        - **Aggressive**: Thorough cleaning that may modify more data
        """)
        
        # Automatically analyze the data when tab is opened
        if 'auto_cleaning_analysis' not in st.session_state:
            with st.spinner("Automatically analyzing data and generating recommendations..."):
                try:
                    # Analyze data and suggest cleaning approaches
                    analysis_results, execution_time = analyze_and_suggest(df)
                    
                    # Store in session state
                    st.session_state.auto_cleaning_analysis = analysis_results
                    st.session_state.auto_cleaning_aggressiveness = analysis_results['recommended_aggressiveness']
                    
                    # Log action
                    log_action(f"Auto-cleaning analysis completed in {execution_time:.2f} seconds")
                except Exception as e:
                    st.error(f"Error analyzing data: {str(e)}")
                    log_action(f"Error in auto-cleaning analysis: {str(e)}", level="ERROR")
        
        # Display analysis results 
        if 'auto_cleaning_analysis' in st.session_state:
            analysis = st.session_state.auto_cleaning_analysis
            
            st.subheader("Data Quality Analysis")
            
            # Display summary metrics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Cells", f"{analysis['overall_impact']['total_cells']:,}")
            
            with col2:
                st.metric("Cells Needing Cleaning", f"{analysis['overall_impact']['impacted_cells']:,}")
            
            with col3:
                st.metric("Impact Percentage", f"{analysis['overall_impact']['impact_percent']:.1f}%")
            
            # Recommendation with clear visual highlight
            st.success(f"🔍 Analysis Complete! Recommended cleaning level: **{analysis['recommended_aggressiveness'].upper()}**")
            
            # Show issue summary
            if 'issue_summary' in analysis:
                with st.expander("View Detailed Issue Summary", expanded=True):
                    st.write(analysis['issue_summary'])
            
            # Select aggressiveness level with the recommended one pre-selected
            aggressiveness = st.radio(
                "Select cleaning aggressiveness:",
                ["minimal", "moderate", "aggressive"],
                index=["minimal", "moderate", "aggressive"].index(st.session_state.auto_cleaning_aggressiveness),
                horizontal=True
            )
            
            # Button to generate preview
            if st.button("Generate Cleaning Preview"):
                with st.spinner("Generating cleaning preview..."):
                    try:
                        # Generate preview of cleaning operations
                        preview = generate_cleaning_preview(df, aggressiveness, sample_rows=5)
                        
                        # Store in session state
                        st.session_state.auto_cleaning_preview = preview
                        
                        # Log action
                        log_action(f"Generated cleaning preview with {aggressiveness} aggressiveness")
                    except Exception as e:
                        st.error(f"Error generating preview: {str(e)}")
                        log_action(f"Error generating preview: {str(e)}", level="ERROR")
            
            # Display preview if available
            if 'auto_cleaning_preview' in st.session_state:
                preview = st.session_state.auto_cleaning_preview
                
                st.subheader("Cleaning Preview")
                
                # Show operations that will be performed
                st.write("**Cleaning operations that will be performed:**")
                
                # Check if cleaning_operations exists and is not None
                if preview and 'cleaning_operations' in preview and preview['cleaning_operations']:
                    for column, operations in preview['cleaning_operations'].items():
                        with st.expander(f"Operations on {column}"):
                            for operation in operations:
                                st.write(f"- {operation}")
                else:
                    st.info("No specific cleaning operations to display in preview.")
                
                # Show before/after samples
                st.write("**Sample data before and after cleaning:**")
                
                col1, col2 = st.columns(2)
                
                # Check if sample data exists
                if preview and 'sample_before' in preview and preview['sample_before'] and 'sample_after' in preview and preview['sample_after']:
                    with col1:
                        st.write("**Before Cleaning:**")
                        st.dataframe(pd.DataFrame(preview['sample_before']), use_container_width=True)
                    
                    with col2:
                        st.write("**After Cleaning:**")
                        st.dataframe(pd.DataFrame(preview['sample_after']), use_container_width=True)
                else:
                    st.info("No sample data available for preview.")
            
            # Button to apply auto-cleaning
            if st.button("Apply Auto-Cleaning"):
                with st.spinner(f"Applying {aggressiveness} auto-cleaning to your data..."):
                    try:
                        # Apply auto-cleaning
                        result = perform_auto_cleaning(df, aggressiveness)
                        
                        # Handle return value which could be a tuple due to timing_decorator
                        if isinstance(result, tuple) and len(result) == 2:
                            # First element is a tuple of (cleaned_df, results)
                            if isinstance(result[0], tuple) and len(result[0]) == 2:
                                cleaned_df = result[0][0]  # The cleaned DataFrame
                                cleaning_results = result[0][1]  # The results dictionary
                                execution_time = result[1]  # Execution time from decorator
                            else:
                                # Unexpected structure, try to handle gracefully
                                cleaned_df = df.copy()
                                cleaning_results = {"cleaning_log": {}, "stats": {"rows_before": len(df), "rows_after": len(df)}}
                                execution_time = 0
                                log_action("Unexpected result structure from auto_cleaning", level="WARNING")
                        else:
                            # Direct return without timing decorator
                            cleaned_df, cleaning_results = result
                            execution_time = 0
                        
                        # Store in session state
                        st.session_state.cleaned_df = cleaned_df
                        st.session_state.cleaning_log = cleaning_results['cleaning_log']
                        st.session_state.auto_cleaning_results = cleaning_results
                        
                        # Log action
                        log_action(f"Auto-cleaning completed with {aggressiveness} aggressiveness in {execution_time:.2f} seconds")
                        
                        st.success("Auto-cleaning completed successfully!")
                    except Exception as e:
                        st.error(f"Error during auto-cleaning: {str(e)}")
                        log_action(f"Error during auto-cleaning: {str(e)}", level="ERROR")
        
        # Display results if available
        if 'auto_cleaning_results' in st.session_state:
            results = st.session_state.auto_cleaning_results
            
            st.subheader("Auto-Cleaning Results")
            
            # Show statistics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Rows Before", results['stats']['rows_before'])
                st.metric("Rows After", results['stats']['rows_after'])
            
            with col2:
                st.metric("Columns Before", results['stats']['columns_before'])
                st.metric("Columns After", results['stats']['columns_after'])
            
            with col3:
                st.metric("Missing Values Before", results['quality_improvement']['missing_values_before'])
                st.metric("Missing Values After", results['quality_improvement']['missing_values_after'])
            
            # Improvement metrics
            st.subheader("Data Quality Improvement")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric(
                    "Missing Values Reduction", 
                    f"{results['quality_improvement']['missing_values_reduction']:,}",
                    f"{results['quality_improvement']['missing_values_reduction_percent']:.1f}%"
                )
            
            with col2:
                st.metric(
                    "Duplicate Rows Removed",
                    results['quality_improvement']['duplicate_rows_removed']
                )
            
            # Compare original vs cleaned
            st.subheader("Data Comparison")
            
            tab1, tab2 = st.tabs(["Original Data", "Cleaned Data"])
            
            with tab1:
                st.dataframe(df.head(10), use_container_width=True)
            
            with tab2:
                st.dataframe(st.session_state.cleaned_df.head(10), use_container_width=True)
            
            # Download cleaned data
            csv = convert_df_to_csv(st.session_state.cleaned_df)
            filename = f"auto_cleaned_{st.session_state.current_file}"
            
            st.download_button(
                "Download Auto-Cleaned Data",
                csv,
                filename,
                "text/csv",
                key='download-auto-cleaned-csv'
            )
            
            # Option to save cleaning configuration
            if st.button("Save this cleaning configuration for future use"):
                # Create a configuration file
                config = {
                    'aggressiveness': results['aggressiveness'],
                    'cleaning_log': results['cleaning_log'],
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                # Convert to JSON
                config_json = json.dumps(config, indent=2)
                
                # Download button
                st.download_button(
                    "Download Cleaning Configuration",
                    config_json,
                    "auto_cleaning_config.json",
                    "application/json",
                    key='download-config'
                )
    else:
        st.info("Please upload a file or select one from the sidebar to use auto-cleaning.")


# ----------------- Tab 5: Visualization -----------------
with tabs[4]:
    st.header("Data Visualization")
    
    if st.session_state.current_df is not None:
        df = st.session_state.current_df
        
        # Choose dataset to visualize
        dataset_option = "Original Data"
        if st.session_state.cleaned_df is not None:
            dataset_option = st.radio(
                "Select dataset to visualize:",
                ["Original Data", "Cleaned Data"],
                horizontal=True
            )
        
        # Set the active dataframe
        active_df = df if dataset_option == "Original Data" else st.session_state.cleaned_df
        
        # Visualization type selector
        viz_type = st.selectbox(
            "Select visualization type:",
            ["Data Distribution", "Missing Values", "Correlation Matrix", "Categorical Data", "Before/After Cleaning"]
        )
        
        # Data Distribution
        if viz_type == "Data Distribution":
            st.subheader("Data Distribution")
            
            # Select columns for visualization
            numeric_cols = active_df.select_dtypes(include=['number']).columns.tolist()
            
            if numeric_cols:
                selected_cols = st.multiselect(
                    "Select columns to visualize:",
                    numeric_cols,
                    default=numeric_cols[:min(3, len(numeric_cols))]
                )
                
                if selected_cols:
                    # Choose plot type
                    plot_type = st.radio(
                        "Select plot type:",
                        ["Histogram", "Box Plot", "Violin Plot"],
                        horizontal=True
                    )
                    
                    if plot_type == "Histogram":
                        # Create histograms
                        for col in selected_cols:
                            fig = px.histogram(
                                active_df,
                                x=col,
                                title=f"Distribution of {col}",
                                marginal="box"
                            )
                            st.plotly_chart(fig, use_container_width=True)
                    
                    elif plot_type == "Box Plot":
                        # Create box plots
                        fig = px.box(
                            active_df,
                            y=selected_cols,
                            title="Box Plots of Selected Columns"
                        )
                        st.plotly_chart(fig, use_container_width=True)
                    
                    elif plot_type == "Violin Plot":
                        # Create violin plots
                        fig = px.violin(
                            active_df,
                            y=selected_cols,
                            title="Violin Plots of Selected Columns",
                            box=True
                        )
                        st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No numeric columns found in the dataset.")
        
        # Missing Values
        elif viz_type == "Missing Values":
            st.subheader("Missing Values Visualization")
            
            # Calculate missing values
            missing_data = active_df.isnull().sum().reset_index()
            missing_data.columns = ['Column', 'Missing Count']
            missing_data['Missing Percentage'] = missing_data['Missing Count'] / len(active_df) * 100
            
            # Sort by missing count
            missing_data = missing_data.sort_values('Missing Count', ascending=False)
            
            # Only show columns with missing values
            missing_data = missing_data[missing_data['Missing Count'] > 0]
            
            if not missing_data.empty:
                # Create bar chart
                fig = px.bar(
                    missing_data,
                    x='Column',
                    y='Missing Percentage',
                    title="Missing Values by Column",
                    text_auto='.1f'
                )
                fig.update_traces(texttemplate='%{text}%', textposition='outside')
                fig.update_layout(uniformtext_minsize=8, uniformtext_mode='hide')
                st.plotly_chart(fig, use_container_width=True)
                
                # Display missing data table
                st.dataframe(missing_data, use_container_width=True)
            else:
                st.success("No missing values found in the dataset!")
        
        # Correlation Matrix
        elif viz_type == "Correlation Matrix":
            st.subheader("Correlation Matrix")
            
            # Calculate correlation for numeric columns
            numeric_df = active_df.select_dtypes(include=['number'])
            
            if not numeric_df.empty:
                # Calculate correlation
                corr = numeric_df.corr()
                
                # Create heatmap
                fig = px.imshow(
                    corr,
                    text_auto='.2f',
                    title="Correlation Matrix",
                    color_continuous_scale='RdBu_r',
                    zmin=-1, zmax=1
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # Show strongest correlations
                st.subheader("Strongest Correlations")
                
                # Unstack correlation matrix
                corr_unstack = corr.unstack().reset_index()
                corr_unstack.columns = ['Column 1', 'Column 2', 'Correlation']
                
                # Remove self-correlations and duplicates
                corr_unstack = corr_unstack[corr_unstack['Column 1'] != corr_unstack['Column 2']]
                corr_unstack['Pair'] = corr_unstack.apply(
                    lambda x: tuple(sorted([x['Column 1'], x['Column 2']])),
                    axis=1
                )
                corr_unstack = corr_unstack.drop_duplicates('Pair')
                
                # Sort by absolute correlation
                corr_unstack['Abs Correlation'] = corr_unstack['Correlation'].abs()
                corr_unstack = corr_unstack.sort_values('Abs Correlation', ascending=False).head(10)
                
                # Display table
                st.dataframe(
                    corr_unstack[['Column 1', 'Column 2', 'Correlation']].reset_index(drop=True),
                    use_container_width=True
                )
            else:
                st.info("No numeric columns found for correlation analysis.")
        
        # Categorical Data
        elif viz_type == "Categorical Data":
            st.subheader("Categorical Data Visualization")
            
            # Identify categorical columns
            categorical_cols = active_df.select_dtypes(include=['object']).columns.tolist()
            
            if categorical_cols:
                selected_col = st.selectbox(
                    "Select categorical column:",
                    categorical_cols
                )
                
                # Count values
                value_counts = active_df[selected_col].value_counts().reset_index().head(20)
                value_counts.columns = ['Value', 'Count']
                
                # Create bar chart
                fig = px.bar(
                    value_counts,
                    x='Value',
                    y='Count',
                    title=f"Value Counts for {selected_col}",
                    text_auto=True
                )
                fig.update_layout(xaxis={'categoryorder':'total descending'})
                st.plotly_chart(fig, use_container_width=True)
                
                # Show table with percentages
                value_counts['Percentage'] = value_counts['Count'] / value_counts['Count'].sum() * 100
                st.dataframe(value_counts, use_container_width=True)
            else:
                st.info("No categorical columns found in the dataset.")
        
        # Before/After Cleaning
        elif viz_type == "Before/After Cleaning" and st.session_state.cleaned_df is not None:
            st.subheader("Before vs After Cleaning Comparison")
            
            # Select column to compare
            common_cols = [col for col in df.columns if col in st.session_state.cleaned_df.columns]
            selected_col = st.selectbox(
                "Select column to compare:",
                common_cols
            )
            
            # Choose comparison type
            if pd.api.types.is_numeric_dtype(df[selected_col]):
                comparison_type = st.radio(
                    "Select comparison type:",
                    ["Distribution", "Missing Values", "Outliers"],
                    horizontal=True
                )
                
                if comparison_type == "Distribution":
                    # Create histograms
                    fig = go.Figure()
                    
                    # Add original data histogram
                    fig.add_trace(go.Histogram(
                        x=df[selected_col],
                        name="Original",
                        opacity=0.75
                    ))
                    
                    # Add cleaned data histogram
                    fig.add_trace(go.Histogram(
                        x=st.session_state.cleaned_df[selected_col],
                        name="Cleaned",
                        opacity=0.75
                    ))
                    
                    # Layout
                    fig.update_layout(
                        title_text=f'Distribution Comparison: {selected_col}',
                        barmode='overlay',
                        xaxis_title=selected_col,
                        yaxis_title="Count"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                elif comparison_type == "Missing Values":
                    # Calculate missing values
                    original_missing = df[selected_col].isna().sum()
                    cleaned_missing = st.session_state.cleaned_df[selected_col].isna().sum()
                    
                    # Create bar chart
                    missing_data = pd.DataFrame({
                        'Dataset': ['Original', 'Cleaned'],
                        'Missing Count': [original_missing, cleaned_missing],
                        'Missing Percentage': [
                            original_missing / len(df) * 100,
                            cleaned_missing / len(st.session_state.cleaned_df) * 100
                        ]
                    })
                    
                    fig = px.bar(
                        missing_data,
                        x='Dataset',
                        y='Missing Count',
                        title=f"Missing Values Comparison: {selected_col}",
                        text_auto=True
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Show percentage reduction
                    if original_missing > 0:
                        reduction = (original_missing - cleaned_missing) / original_missing * 100
                        st.info(f"Missing values reduction: {reduction:.1f}%")
                
                elif comparison_type == "Outliers":
                    # Calculate outliers using IQR method
                    def get_outliers(series):
                        q1 = series.quantile(0.25)
                        q3 = series.quantile(0.75)
                        iqr = q3 - q1
                        lower_bound = q1 - (1.5 * iqr)
                        upper_bound = q3 + (1.5 * iqr)
                        return (series < lower_bound) | (series > upper_bound)
                    
                    original_outliers = get_outliers(df[selected_col].dropna())
                    cleaned_outliers = get_outliers(st.session_state.cleaned_df[selected_col].dropna())
                    
                    # Count outliers
                    original_count = original_outliers.sum()
                    cleaned_count = cleaned_outliers.sum()
                    
                    # Create bar chart
                    outlier_data = pd.DataFrame({
                        'Dataset': ['Original', 'Cleaned'],
                        'Outlier Count': [original_count, cleaned_count],
                        'Outlier Percentage': [
                            original_count / len(df[selected_col].dropna()) * 100,
                            cleaned_count / len(st.session_state.cleaned_df[selected_col].dropna()) * 100
                        ]
                    })
                    
                    fig = px.bar(
                        outlier_data,
                        x='Dataset',
                        y='Outlier Count',
                        title=f"Outliers Comparison: {selected_col}",
                        text_auto=True
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Show percentage reduction
                    if original_count > 0:
                        reduction = (original_count - cleaned_count) / original_count * 100
                        st.info(f"Outliers reduction: {reduction:.1f}%")
            
            else:
                # For categorical columns
                # Create value frequency comparison
                original_counts = df[selected_col].value_counts().reset_index().head(10)
                original_counts.columns = ['Value', 'Original Count']
                
                cleaned_counts = st.session_state.cleaned_df[selected_col].value_counts().reset_index().head(10)
                cleaned_counts.columns = ['Value', 'Cleaned Count']
                
                # Merge the counts
                merged_counts = pd.merge(original_counts, cleaned_counts, on='Value', how='outer').fillna(0)
                
                # Calculate percentages
                merged_counts['Original %'] = merged_counts['Original Count'] / merged_counts['Original Count'].sum() * 100
                merged_counts['Cleaned %'] = merged_counts['Cleaned Count'] / merged_counts['Cleaned Count'].sum() * 100
                
                # Show table
                st.dataframe(merged_counts, use_container_width=True)
                
                # Create grouped bar chart
                fig = go.Figure()
                
                # Add original data bars
                fig.add_trace(go.Bar(
                    x=merged_counts['Value'],
                    y=merged_counts['Original Count'],
                    name="Original",
                ))
                
                # Add cleaned data bars
                fig.add_trace(go.Bar(
                    x=merged_counts['Value'],
                    y=merged_counts['Cleaned Count'],
                    name="Cleaned",
                ))
                
                # Layout
                fig.update_layout(
                    title_text=f'Frequency Comparison: {selected_col}',
                    xaxis_title="Value",
                    yaxis_title="Count",
                    barmode='group'
                )
                
                st.plotly_chart(fig, use_container_width=True)
        else:
            if viz_type == "Before/After Cleaning":
                st.info("Please clean your data first to use this visualization.")
    else:
        st.info("Please upload a file or select one from the sidebar to visualize it.")


# ----------------- Tab 6: Multi-File Analysis -----------------
with tabs[5]:
    st.header("Multi-File Analysis")
    
    # Initialize session state for multiple files
    if 'multi_file_data' not in st.session_state:
        st.session_state.multi_file_data = {}
    
    # Upload section for multiple files
    st.subheader("Upload Multiple Files")
    
    uploaded_files = st.file_uploader(
        "Upload multiple CSV files for comparison",
        type=["csv"],
        accept_multiple_files=True,
        key="multi_file_uploader"
    )
    
    # Process uploaded files
    if uploaded_files:
        for file in uploaded_files:
            # Check if this file is already processed
            if file.name not in st.session_state.multi_file_data:
                with st.spinner(f"Processing {file.name}..."):
                    try:
                        # Check file size
                        if is_large_file(file):
                            # For large files, use Dask
                            file_size = get_file_size(file)
                            st.warning(f"Large file detected ({file_size}). Using optimized processing...")
                            
                            # Reset the file pointer
                            file.seek(0)
                            
                            # Try to infer encoding
                            encoding = infer_encoding(file)
                            file.seek(0)
                            
                            # Try to determine delimiter
                            delimiter = determine_delimiter(file)
                            file.seek(0)
                            
                            # Process with Dask
                            import dask.dataframe as dd
                            df = dd.read_csv(
                                file, 
                                encoding=encoding, 
                                sep=delimiter, 
                                assume_missing=True,
                                sample=1000
                            ).compute()
                        else:
                            # Regular processing for normal files
                            encoding = infer_encoding(file)
                            file.seek(0)  # Reset file position
                            delimiter = determine_delimiter(file)
                            file.seek(0)  # Reset file position
                            
                            df = pd.read_csv(file, encoding=encoding, sep=delimiter)
                        
                        # Analyze and store the data
                        issues = identify_data_issues(df)
                        quality_report = get_data_quality_report(df)
                        
                        # Store in session state
                        st.session_state.multi_file_data[file.name] = {
                            'df': df,
                            'issues': issues,
                            'quality_report': quality_report,
                            'file_size': get_file_size(file)
                        }
                        
                        # Auto analyze for cleaning
                        try:
                            analysis_results, execution_time = analyze_and_suggest(df)
                            
                            # Store the analysis results
                            st.session_state.multi_file_data[file.name]['auto_cleaning_analysis'] = analysis_results
                            
                            # Log action
                            log_action(f"Auto-cleaning analysis for {file.name} completed in {execution_time:.2f} seconds")
                        except Exception as e:
                            st.warning(f"Could not complete auto-cleaning analysis for {file.name}: {str(e)}")
                            log_action(f"Error in auto-cleaning analysis for {file.name}: {str(e)}", level="ERROR")
                        
                        # Log action
                        log_action(f"Processed {file.name} for multi-file analysis")
                        
                    except Exception as e:
                        st.error(f"Error processing {file.name}: {str(e)}")
                        log_action(f"Error processing {file.name}: {str(e)}", level="ERROR")
    
    # Display multi-file analysis if files are loaded
    if st.session_state.multi_file_data:
        st.subheader("Comparative Analysis")
        
        # Display side-by-side stats
        st.write("### Dataset Comparison")
        
        # Set up table data for comparison
        comparison_data = []
        for filename, data in st.session_state.multi_file_data.items():
            df = data['df']
            qr = data['quality_report']
            
            # Get missing values and duplicates percentages
            missing_pct = qr['missing_data']['percent_missing'] if 'missing_data' in qr else 0
            duplicate_pct = qr['duplicate_rows']['percent'] if 'duplicate_rows' in qr else 0
            
            file_info = {
                'Filename': filename,
                'Rows': len(df),
                'Columns': len(df.columns),
                'Size': data['file_size'],
                'Missing Values %': missing_pct,
                'Numeric Columns': len(df.select_dtypes(include=['number']).columns),
                'Categorical Columns': len(df.select_dtypes(include=['object']).columns),
                'Datetime Columns': len(df.select_dtypes(include=['datetime']).columns),
                'Duplicates %': duplicate_pct,
                'Quality Score': round(100 - missing_pct - duplicate_pct, 1)
            }
            comparison_data.append(file_info)
        
        # Convert to DataFrame for display
        comparison_df = pd.DataFrame(comparison_data)
        st.dataframe(comparison_df, use_container_width=True)
        
        # Data distribution comparison
        st.write("### Data Distribution Comparison")
        
        # Select files to compare
        compare_files = st.multiselect(
            "Select files to compare:", 
            list(st.session_state.multi_file_data.keys()),
            default=list(st.session_state.multi_file_data.keys())[:min(2, len(st.session_state.multi_file_data))]
        )
        
        if len(compare_files) >= 2:
            # Select common numeric columns
            all_numeric_cols = [
                set(st.session_state.multi_file_data[file]['df'].select_dtypes(include=['number']).columns)
                for file in compare_files
            ]
            common_numeric_cols = list(set.intersection(*map(set, all_numeric_cols)))
            
            if common_numeric_cols:
                # Select columns to compare
                selected_cols = st.multiselect(
                    "Select common numeric columns to compare:", 
                    common_numeric_cols,
                    default=common_numeric_cols[:min(1, len(common_numeric_cols))]
                )
                
                if selected_cols:
                    # Choose visualization type
                    viz_type = st.selectbox(
                        "Select visualization type:",
                        ["Box Plot", "Distribution Plot", "Violin Plot"]
                    )
                    
                    # Create the visualization
                    for column in selected_cols:
                        # Prepare data for comparison
                        if viz_type == "Box Plot":
                            # Combine data for box plot
                            plot_data = []
                            for file in compare_files:
                                df = st.session_state.multi_file_data[file]['df']
                                if column in df.columns and pd.api.types.is_numeric_dtype(df[column]):
                                    temp_df = pd.DataFrame({
                                        'value': df[column].dropna(),
                                        'dataset': file
                                    })
                                    plot_data.append(temp_df)
                            
                            if plot_data:
                                combined_df = pd.concat(plot_data)
                                fig = px.box(
                                    combined_df, 
                                    x='dataset', 
                                    y='value',
                                    title=f"Box Plot of {column} Across Selected Datasets",
                                    points="all"
                                )
                                st.plotly_chart(fig, use_container_width=True)
                            
                        elif viz_type == "Distribution Plot":
                            # Create overlapping histograms
                            fig = go.Figure()
                            for file in compare_files:
                                df = st.session_state.multi_file_data[file]['df']
                                if column in df.columns and pd.api.types.is_numeric_dtype(df[column]):
                                    fig.add_trace(go.Histogram(
                                        x=df[column].dropna(),
                                        name=file,
                                        opacity=0.6,
                                        nbinsx=30
                                    ))
                            
                            fig.update_layout(
                                title=f"Distribution of {column} Across Selected Datasets",
                                xaxis_title=column,
                                yaxis_title="Count",
                                barmode='overlay'
                            )
                            st.plotly_chart(fig, use_container_width=True)
                            
                        elif viz_type == "Violin Plot":
                            # Combine data for violin plot
                            plot_data = []
                            for file in compare_files:
                                df = st.session_state.multi_file_data[file]['df']
                                if column in df.columns and pd.api.types.is_numeric_dtype(df[column]):
                                    temp_df = pd.DataFrame({
                                        'value': df[column].dropna(),
                                        'dataset': file
                                    })
                                    plot_data.append(temp_df)
                            
                            if plot_data:
                                combined_df = pd.concat(plot_data)
                                fig = px.violin(
                                    combined_df, 
                                    x='dataset', 
                                    y='value',
                                    title=f"Violin Plot of {column} Across Selected Datasets",
                                    box=True
                                )
                                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("No common numeric columns found across the selected datasets.")
        else:
            st.info("Please select at least 2 files to compare.")
        
        # Data quality comparison
        st.write("### Data Quality Comparison")
        
        # Prepare quality data for comparison
        quality_data = []
        for filename, data in st.session_state.multi_file_data.items():
            qr = data['quality_report']
            
            # Get missing values and duplicates percentages
            missing_pct = qr['missing_data']['percent_missing'] if 'missing_data' in qr else 0
            duplicate_pct = qr['duplicate_rows']['percent'] if 'duplicate_rows' in qr else 0
            
            # Calculate quality score
            quality_score = round(100 - missing_pct - duplicate_pct, 1)
            
            # Get outlier percentage if available
            outlier_pct = 0
            # Try to estimate outliers from column data if available
            if 'column_details' in qr:
                outlier_cols = 0
                total_outlier_pct = 0
                for col, details in qr.get('column_details', {}).items():
                    if 'outliers_percent' in details:
                        outlier_cols += 1
                        total_outlier_pct += details['outliers_percent']
                if outlier_cols > 0:
                    outlier_pct = total_outlier_pct / outlier_cols
            
            quality_info = {
                'Dataset': filename,
                'Quality Score': quality_score,
                'Missing Values %': missing_pct,
                'Duplicate Rows %': duplicate_pct,
                'Outliers %': outlier_pct
            }
            quality_data.append(quality_info)
        
        # Create bar chart for quality comparison
        if quality_data:
            quality_df = pd.DataFrame(quality_data)
            
            # Create stacked bar chart
            fig = go.Figure()
            
            # Add bars for different quality metrics
            fig.add_trace(go.Bar(
                x=quality_df['Dataset'],
                y=quality_df['Missing Values %'],
                name='Missing Values %',
                marker_color='#FF9999'
            ))
            
            fig.add_trace(go.Bar(
                x=quality_df['Dataset'],
                y=quality_df['Duplicate Rows %'],
                name='Duplicate Rows %',
                marker_color='#99CCFF'
            ))
            
            fig.add_trace(go.Bar(
                x=quality_df['Dataset'],
                y=quality_df['Outliers %'],
                name='Outliers %',
                marker_color='#FFCC99'
            ))
            
            # Add quality score as line
            fig.add_trace(go.Scatter(
                x=quality_df['Dataset'],
                y=quality_df['Quality Score'],
                mode='lines+markers',
                name='Quality Score',
                line=dict(color='green', width=2),
                marker=dict(size=8),
            ))
            
            # Update layout
            fig.update_layout(
                title='Data Quality Comparison',
                xaxis_title='Dataset',
                yaxis_title='Percentage (%)',
                barmode='stack',
                yaxis=dict(range=[0, 100])
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        # Auto-cleaning recommendations comparison
        st.write("### Auto-Cleaning Recommendations")
        
        # Collect recommendations for each file
        recommendations_data = []
        for filename, data in st.session_state.multi_file_data.items():
            if 'auto_cleaning_analysis' in data:
                analysis = data['auto_cleaning_analysis']
                
                # Get impact percentage
                impact_percent = analysis['overall_impact'].get('impact_percent', 0)
                
                # Get recommended aggressiveness
                recommendation = {
                    'Dataset': filename,
                    'Recommended Level': analysis.get('recommended_aggressiveness', 'moderate'),
                    'Impact %': impact_percent,
                    'Issues Found': len(analysis.get('issue_summary', {}))
                }
                
                recommendations_data.append(recommendation)
        
        if recommendations_data:
            rec_df = pd.DataFrame(recommendations_data)
            
            # Create visualization
            fig = px.bar(
                rec_df,
                x='Dataset',
                y='Impact %',
                color='Recommended Level',
                title='Auto-Cleaning Impact Comparison',
                hover_data=['Issues Found'],
                text_auto='.1f'
            )
            
            fig.update_traces(texttemplate='%{text}%', textposition='outside')
            st.plotly_chart(fig, use_container_width=True)
            
            # Display recommendations table
            st.dataframe(rec_df, use_container_width=True)
    else:
        st.info("Upload multiple CSV files to perform comparative analysis.")

# ----------------- Tab 7: Processing Logs -----------------
with tabs[6]:
    st.header("Processing Logs")
    
    # Refresh logs button
    if st.button("Refresh Logs"):
        st.rerun()
    
    # Get recent logs
    recent_logs = get_logs(n=100)
    
    if recent_logs:
        st.subheader("Recent Activity")
        log_text = "".join(recent_logs)
        st.text_area("Log entries:", log_text, height=400)
        
        # Option to download logs
        st.download_button(
            "Download Complete Logs",
            "".join(get_logs()),
            "data_pipeline_logs.txt",
            "text/plain",
            key='download-logs'
        )
    else:
        st.info("No logs available yet.")


# Set up .streamlit directory and config
def setup_streamlit_config():
    """Create streamlit config directory and configuration file."""
    config_dir = ".streamlit"
    if not os.path.exists(config_dir):
        os.makedirs(config_dir)
    
    config_path = os.path.join(config_dir, "config.toml")
    if not os.path.exists(config_path):
        with open(config_path, "w") as f:
            f.write("""
[server]
headless = true
address = "0.0.0.0"
port = 5000
            """)

# Run setup on script load
setup_streamlit_config()

# Main entry point
if __name__ == "__main__":
    # App is already running via streamlit
    pass
